% Optimisation Tool Box Caller Function        %
% For optimisation, select the genetic algorithm %
% option and set it's parameters                 % 
function y = abcd(x)
    y = BackPropAlgo(x);
end
