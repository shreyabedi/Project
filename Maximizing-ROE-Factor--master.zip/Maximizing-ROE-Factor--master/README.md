# Maximizing-ROE-Factor-
Project on maximizing ROE factor for a company using Machine learning techniques and Tracking algorithm solely made by self inspired from real life trading techniques.

THe following code uses Genetic Algorithm and Linear Regression techniques to predict the price of the Stock Invested by the user in MATLAB.
The algorithm is based in MATLAB which flags the times to buy or sell the stock according to the technical indicators such as:
1.Moving average of 20 Days
2.Moving average of 10 Days

The monitoring algorithm or the long term investment algorithm has proven to give good returns over a long period of time such as > 10 mos 
Some conditions are qualified by the algorithm to flag the current timestamp to be good for BUY/SELL.
